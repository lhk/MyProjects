
#include "stdafx.h"
#include <windows.h>
#include <iostream>
#define BARHEIGHT 150
#define BARCOUNT 3

const LPCWSTR g_szClassName = L"myWindowClass";
enum { ID_SCROLLBAR = 1,};

HWND hwnd;
HDC hdc;
PAINTSTRUCT	ps;
HINSTANCE hInstance;
HWND scrollBar;
POINT p;
HBRUSH brush;
int bars[BARCOUNT];
int plist_index = 0;


int plist[][3] = 
{
	{111,61,33},
{96,50,71},
{89,36,121},
{90,64,17},
{79,55,57},
{75,40,107},
{59,64,18},
{61,54,59},
{62,40,108},
{35,59,38},
{44,49,77},
{48,32,128},
{109,89,37},
{94,71,74},
{88,51,126},
{87,118,22},
{78,78,61},
{75,58,109},
{57,141,23},
{59,77,63},
{59,56,111},
{33,87,44},
{43,70,79},
{46,49,131},
};


// Step 4: the Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	int CurPos = 0;
    switch(msg)
    {
		case WM_CREATE:			
			break;

		case WM_LBUTTONDOWN:
			
			GetCursorPos(&p);
			ScreenToClient(hwnd, &p);

			

			if(p.x < 800)
			{
				if(p.y / BARHEIGHT < BARCOUNT)
					bars[p.y / BARHEIGHT] = p.x*180/800;
			}

			wchar_t str[ 100 ];
			wsprintf(str,L"%i;%i;%i",bars[0],bars[1],bars[2]);
			SetWindowText(hwnd, str);

			InvalidateRect (hwnd, NULL, TRUE);
			UpdateWindow (hwnd);

			break;

		case WM_PAINT: 
			hdc = BeginPaint(hwnd, &ps);

			brush = CreateSolidBrush(RGB(0,0,0));
			SelectObject(hdc, brush);

			for(int i = 0; i < BARCOUNT; i++)
			{
				Rectangle(hdc, bars[i]*800/180,i*BARHEIGHT,bars[i]*800/180+10,(i+1)*BARHEIGHT);
			}

			
			DeleteObject(brush);

			EndPaint(hwnd, &ps);
			return 0;

        case WM_CLOSE:
            DestroyWindow(hwnd);
        break;
        case WM_DESTROY:
            PostQuitMessage(0);
        break;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE _hInstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int nCmdShow)
{
    WNDCLASSEX wc;
	hInstance = _hInstance;    
    MSG Msg;

    //Step 1: Registering the Window Class
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = 0;
    wc.lpfnWndProc   = WndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = g_szClassName;
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if(!RegisterClassEx(&wc))
    {
        MessageBox(NULL, L"Window Registration Failed!", L"Error!",
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    // Step 2: Creating the Window
    hwnd = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        g_szClassName,
        L"The title of my window",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600,
        NULL, NULL, hInstance, NULL);

    if(hwnd == NULL)
    {
        MessageBox(NULL, L"Window Creation Failed!", L"Error!",
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);


	Serial ser = Serial(L"COM3");
	bars[0] = 60;
	bars[1] = 80;
	bars[2] = 90;

	DWORD LastTime = GetTickCount();


    do
	{
		if(PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE) > 0)
		{
			TranslateMessage(&Msg);
			DispatchMessage(&Msg);
		}
		

		
		DWORD Time = GetTickCount();
		if(Time - LastTime > 2000) 
		{
			plist_index = (plist_index + 1) % 24;
			LastTime = Time;
		}


		unsigned char buffer[BARCOUNT+1];
		buffer[0] = 255;
		for(int i = 0; i < BARCOUNT; i++) buffer[i+1] = min((unsigned char)(bars[i]),(unsigned char)254);
		//for(int i = 0; i < BARCOUNT; i++) buffer[i+1] = min((unsigned char)(plist[plist_index][i]),(unsigned char)254);
		ser.WriteData((char*)&buffer,BARCOUNT+1);





		Sleep(1);

	}while(WM_QUIT != Msg.message);
    return Msg.wParam;
}